# Reprogramador de Imagens v5 — Marketplaces

## Novidades

- marketplace padrão para novos arquivos;
- marketplace individual em cada item da fila;
- perfis de dimensão:
  - Mercado Livre: 1200×1200;
  - Shopee: 1200×1200;
  - TikTok Shop: 1000×1000;
  - SHEIN: 1200×1600;
  - Amazon: 1600×1600;
  - Outros: tamanho personalizado;
  - Sem perfil: dimensões originais;
- enquadramento “encaixar sem cortar” ou “preencher e cortar”;
- cor de fundo configurável;
- botão para duplicar a mesma imagem e gerar versões para vários marketplaces;
- organização opcional em subpastas por marketplace;
- ZIP organizado por marketplace;
- relatório CSV com perfil, dimensões e enquadramento;
- mantém fila em lote, limite de 2 MB, alteração mínima de pixels, pasta de saída e numeração contínua.

## Atualização no GitHub

Substitua apenas o `index.html` atual por este arquivo e faça o commit. Depois, aguarde o GitHub Pages publicar e use uma atualização forçada no navegador.

## Observação

Os perfis de Shopee e SHEIN são recomendações operacionais editáveis do sistema, porque as páginas públicas dessas plataformas não apresentam uma especificação única e universal para todas as categorias. O perfil não garante aprovação ou ranqueamento; regras de categoria e de conteúdo continuam aplicáveis.
